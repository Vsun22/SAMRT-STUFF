## About tool
All in one Instagram hacking tool available (Insta information gathering, Insta brute force, Insta account auto repoter)

## Features:

- Insta information gathering
- Insta brute force attack
- Insta auto repoter
- Update script
- Remove script

## Requirements
- Data connection
- Internet 200MB
- storage 400MB
- No Root

## Available On
- Termux
- Kali Linux

## Test On:
- Termux
- Mi Note 9 pro

## INSTALLATION [Termux]

* `apt update`
* `apt upgrade`
* `pkg install python`
* `pkg install python2`
* `pkg install git`
* `git clone https://github.com/IncredibleHacker/insta-hack`
* `ls`
* `cd insta-hack`
* `pip3 install -r requirements.txt`
* `chmod +x *`
* `bash setup.sh`
* `bash insta-hack.sh`

## INSTALLATION [Kali Linux]

* `sudo apt install python`
* `sudo apt install python2`
* `sudo apt install git`
* `git clone https://github.com/IncredibleHacker/insta-hack`
* `ls`
* `cd insta-hack`
* `pip3 install -r requirements.txt`
* `chmod +x *`
* `sudo bash insta-hack.sh`

## Screenshot:
<br>
<p align="center">
<img width="95%" src="https://github.com/IncredibleHacker/insta-hack/blob/main/Ig_information_gathering/Core_files/IMG_20210725_122737.jpg"\>

## Warning:
#### This tool is only for educational purpose. If you use this tool for other purposes except education we will not be responsible in such cases
